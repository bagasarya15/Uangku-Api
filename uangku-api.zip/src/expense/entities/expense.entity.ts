export class Expense {}
