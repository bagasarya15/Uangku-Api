export class Income {}
